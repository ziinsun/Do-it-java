package test;

public class DogTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Dog []dogs = new Dog[4];
		
		dogs[0] = new Dog("bbibbi","maltiz");
		dogs[1] = new Dog("walwal","huski");
		dogs[2] = new Dog("mungmung","pekinez");
		
		for (int i = 0; i < dogs.length; i++) {
			dogs[i].showDogInfo();
		}
		
		System.out.println("==향상된 for===");
		for (Dog dog : dogs) {
			dog.showDogInfo();
		}
	}

}
