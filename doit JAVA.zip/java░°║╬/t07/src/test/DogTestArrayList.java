package test;

import java.util.ArrayList;

public class DogTestArrayList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Dog> dogs = new ArrayList<Dog>();
		
		dogs.add(new Dog("bbibbi","maltiz"));
		dogs.add(new Dog("walwal","huski"));
		dogs.add(new Dog("mungmung","pekiniz"));
		
		for (int i = 0; i < dogs.size(); i++) {
			Dog dog = dogs.get(i);
			dog.showDogInfo();
		}
		
		System.out.println();
		
		System.out.println("향상된for");
		for (Dog dog : dogs) {
			dog.showDogInfo();
		}
	}

}
