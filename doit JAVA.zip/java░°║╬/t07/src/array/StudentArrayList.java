package array;

import java.util.ArrayList;

public class StudentArrayList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Student> student = new ArrayList<Student>();
		
		student.add(new Student("James",1001));
		student.add(new Student("Tomas",1002));
		student.add(new Student("Edward",1003));
		
		for (int i = 0; i < student.size(); i++) {
			Student studentID = student.get(i);
			studentID.showStudentInfo();
		}
	}

}
