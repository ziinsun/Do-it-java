package array;

public class Student {
	int studentID;
	String name;
	
	public Student(String name, int studentID) {
		this.name=name;
		this.studentID=studentID;
	}
	
	public int getStudentID() {
		return studentID;
	}
	public void setStudentID(int studentID) {
		this.studentID = studentID;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public void showStudentInfo() {
		System.out.println(studentID+","+name);
	}
}
