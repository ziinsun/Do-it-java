package array;

public class EnhancedForLoop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String[] strArray = { "Java", "Android", "C", "JavaScript", "Python" };

		for (String lang : strArray) {
			System.out.println(lang);
		}
	}

}
