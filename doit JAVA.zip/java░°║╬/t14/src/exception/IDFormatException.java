package exception;

public class IDFormatException extends Exception{
	public IDFormatException(String message) {
		super(message);
	}
}
