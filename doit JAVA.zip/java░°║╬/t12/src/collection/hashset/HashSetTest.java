package collection.hashset;

import java.util.HashSet;

public class HashSetTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashSet<String> hashSet = new HashSet<String>();
		hashSet.add(new String("임정순"));
		hashSet.add(new String("ㅂㅎㅈ"));
		hashSet.add(new String("ㅎㅇㅇ"));
		hashSet.add(new String("ㄱㄱㅊ"));
		hashSet.add(new String("ㄱㄱㅊ"));
		
		System.out.println(hashSet);
	}

}
