package collection.treeset;

import collection.Member;

public class MemberTreeSetTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MemberTreeSet memberTreeSet = new MemberTreeSet();
		
		Member memberPark = new Member(1003,"박서훤");
		
		memberTreeSet.addMember(memberPark);
		
		Member memberHong = new Member(1003,"홍길동");
		memberTreeSet.addMember(memberHong);
		memberTreeSet.showAllMember();
	}

}
