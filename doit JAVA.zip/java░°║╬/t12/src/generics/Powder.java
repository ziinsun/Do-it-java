package generics;

public class Powder extends Material {
	public void doPrinting() {
		System.out.println("Powder재료로 출력합니다");
	}
	
	public String toString() {
		return "재료는 powder입니다";
	}
}
