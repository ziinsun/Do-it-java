package test;

public class MyDate {
	private int day; 
	private int month; 
	private int year;

	public int getDay() {
		return day;
	}

	public void setDay(int day) {
		this.day = day;

	}

	public int getMonth() {
		return month;
	}

	public void setMonth(int month) {
		this.month = month;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public MyDate(int day, int month, int year) {
		setYear(year);
		setMonth(month);
		setDay(day);
	}

	public String isValid() {
		if (month == 2) {
			if (day < 1 || day > 28)
				return "invalid date";
			else
				return "valid date";
		}
		return "valid date";

	}
}
