package reference;

public class Student3 {
	int studentID;
	String studentName;
	Subject korean;
	Subject math;
}
