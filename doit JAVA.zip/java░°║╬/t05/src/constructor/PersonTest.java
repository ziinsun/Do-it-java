package constructor;

public class PersonTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Person personKim = new Person();
		personKim.name="김유신";
		personKim.weight=85.5F;
		personKim.height=180.0F;
		
		Person PersonLee = new Person("이순신",175,75);
	}

}
