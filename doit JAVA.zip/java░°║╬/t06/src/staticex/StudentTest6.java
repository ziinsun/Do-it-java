package staticex;

public class StudentTest6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student3 studentLee = new Student3();
		studentLee.setStudentName("이지원");
//		System.out.println(studentLee.cardNum);
//		System.out.println(studentLee.studentName+"학번:"+studentLee.studentID);
		
		Student3 studentSon = new Student3();
		studentSon.setStudentName("손수경");
//		System.out.println(studentSon.cardNum);
//		System.out.println(studentSon.studentName+"학번:"+studentSon.studentID);
		System.out.println(studentSon.toString());
	}

}
