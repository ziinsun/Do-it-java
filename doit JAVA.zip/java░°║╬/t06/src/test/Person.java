package test;

public class Person {
//	public static int serialNum = 1000;
//	public int cardNum;
//	public String personName;
//	
//	public Person() {
//		serialNum++;
//		cardNum=serialNum;
//	}
//
//	public String getPersonName() {
//		return personName;
//	}
//
//	public void setPersonName(String personName) {
//		this.personName = personName;
//	}
//	
//	
	private static Person instance = new Person();
	private Person() {}
	
	public static Person getInstance() {
		if(instance==null) {
			instance = new Person();
		}
		return instance;
	}
	
}
