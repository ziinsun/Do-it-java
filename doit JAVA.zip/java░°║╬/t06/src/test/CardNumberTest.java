package test;

public class CardNumberTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		Person personKim = new Person();
//		personKim.setPersonName("김진선");
//		System.out.println(personKim.personName+" 카드 번호: "+personKim.cardNum);
		
		Person person1 = Person.getInstance();
		
	}

}
