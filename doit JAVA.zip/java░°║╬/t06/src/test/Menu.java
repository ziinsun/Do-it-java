package test;

public class Menu {

	public static int americano = 4000;
	public static int latte = 4500;
}

	
