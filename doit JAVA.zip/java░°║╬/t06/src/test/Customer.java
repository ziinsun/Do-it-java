package test;

public class Customer {
	public String customerName;
	public int money;
	public String coffee;
	
	Menu menu = new Menu();
	public Customer(String customerName, int money,String coffee) {
		this.customerName=customerName;
		this.money=money;
		this.coffee = coffee;
	}
	
	public void Cafe(Menu menu, int money) {
		this.money-=menu.americano;
		System.out.println(customerName+"님의 남은 돈은"+money+"입니다");
	}
	
//	public void Cafe(Menu menu, int money) {
//		this.money-=menu.latte;
//		System.out.println(customerName+"님의 남은 돈은"+money+"입니다");
//	}
	
	
	
}
