package test;

public class Cafe {
	
}
