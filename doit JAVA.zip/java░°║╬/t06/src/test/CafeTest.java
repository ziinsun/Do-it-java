package test;

public class CafeTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Customer kim = new Customer("Kim",10000,"americano");
		Cafe cafe = new Cafe();
		Customer Lee = new Customer("Lee",10000,"latte");
	}

}
