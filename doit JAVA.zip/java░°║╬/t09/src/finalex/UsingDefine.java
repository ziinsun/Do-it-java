package finalex;

public class UsingDefine {
	public static void main(String[] args) {
		
		System.out.println(Define.GOOD_MORNING);
		System.out.println(Define.MIN);
		System.out.println(Define.MAX);
		System.out.println(Define.MATH);
		System.out.println(Define.ENG);
	}
}
