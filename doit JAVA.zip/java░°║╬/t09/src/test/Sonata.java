package test;

public class Sonata extends Car{

	
	
	@Override
	public void start() {
		// TODO Auto-generated method stub
		System.out.println("sonata 시동을 켭니다");
	}

	@Override
	public void drive() {
		// TODO Auto-generated method stub
		System.out.println("sonata 달립니다");
	}

	@Override
	public void stop() {
		// TODO Auto-generated method stub
		System.out.println("sonata 멈춥니다");
	}

	@Override
	public void turnoff() {
		// TODO Auto-generated method stub
		System.out.println("sonata 시동을 끕니다");
	}
	

}
