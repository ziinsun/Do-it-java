package test;

public class CarModel {

}
