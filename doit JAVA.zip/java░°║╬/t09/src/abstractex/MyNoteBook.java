package abstractex;

public class MyNoteBook extends NoteBook {

	@Override
	public void typing() {
		// TODO Auto-generated method stub
		
	}
	
}
