package abstractex;

public abstract class NoteBook extends Computer{

	@Override
	public void display() {
		// TODO Auto-generated method stub
		System.out.println("NoteBook display()");
	}
	
}
